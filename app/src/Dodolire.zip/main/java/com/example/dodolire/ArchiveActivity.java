package com.example.dodolire;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import android.graphics.Typeface;

public class ArchiveActivity extends AppCompatActivity {

    private LinearLayout archiveContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_archive);

        archiveContainer = findViewById(R.id.archive_container);

        setupHeaderActions();
        loadArchivedStories();
    }

    private void setupHeaderActions() {
        ImageView profileIcon = findViewById(R.id.profile);
        ImageView menuIcon = findViewById(R.id.icon_menu);
        ImageView backIcon = findViewById(R.id.icon_back);

        profileIcon.setOnClickListener(v -> startActivity(new Intent(ArchiveActivity.this, ProfileActivity.class)));

        menuIcon.setOnClickListener(v -> {
            MenuHelper.showBurgerMenu(this, v);
        });

        backIcon.setOnClickListener(v -> finish());
    }

    private void loadArchivedStories() {
        archiveContainer.removeAllViews();

        SharedPreferences sharedPreferences = getSharedPreferences("archived_stories", MODE_PRIVATE);
        int archivedCount = sharedPreferences.getInt("archived_count", 0);

        if (archivedCount == 0) {
            TextView emptyText = new TextView(this);
            emptyText.setText("Aucune histoire archivée");
            emptyText.setTextSize(16);
            emptyText.setPadding(16, 32, 16, 16);
            emptyText.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            archiveContainer.addView(emptyText);
        } else {
            for (int i = archivedCount - 1; i >= 0; i--) {
                String title = sharedPreferences.getString("archived_title_" + i, "");
                String content = sharedPreferences.getString("archived_content_" + i, "");
                String theme = sharedPreferences.getString("archived_theme_" + i, "");
                String character = sharedPreferences.getString("archived_character_" + i, "");
                String date = sharedPreferences.getString("archived_date_" + i, "");

                addStoryCard(title, content, theme, character, date, i);
            }
        }
    }

    private void addStoryCard(String title, String content, String theme, String character, String date, final int position) {
        CardView cardView = new CardView(this);
        cardView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        cardView.setRadius(16);
        cardView.setCardElevation(4);
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) cardView.getLayoutParams();
        layoutParams.setMargins(0, 0, 0, 16);
        cardView.setLayoutParams(layoutParams);

        LinearLayout contentLayout = new LinearLayout(this);
        contentLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        contentLayout.setOrientation(LinearLayout.HORIZONTAL);
        contentLayout.setPadding(16, 16, 16, 16);

        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(100, 100));
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setContentDescription("Image de l'histoire");
        setThemeImage(imageView, theme);

        LinearLayout textContainer = new LinearLayout(this);
        textContainer.setLayoutParams(new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f
        ));
        textContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textContainerParams = (LinearLayout.LayoutParams) textContainer.getLayoutParams();
        textContainerParams.setMarginStart(16);
        textContainer.setLayoutParams(textContainerParams);

        TextView titleText = new TextView(this);
        titleText.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        titleText.setText(title);
        titleText.setTextSize(18);
        titleText.setTextColor(ContextCompat.getColor(this, android.R.color.black));
        titleText.setMaxLines(2);
        titleText.setEllipsize(android.text.TextUtils.TruncateAt.END);

        TextView dateText = new TextView(this);
        dateText.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        dateText.setText(date);
        dateText.setTextSize(14);
        dateText.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
        LinearLayout.LayoutParams dateParams = (LinearLayout.LayoutParams) dateText.getLayoutParams();
        dateParams.topMargin = 8;
        dateText.setLayoutParams(dateParams);

        TextView tapToReadText = new TextView(this);
        tapToReadText.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        tapToReadText.setText("Appuyer pour lire");
        tapToReadText.setTextSize(12);
        tapToReadText.setTextColor(ContextCompat.getColor(this, android.R.color.holo_blue_dark));
        tapToReadText.setTypeface(null, Typeface.ITALIC);
        LinearLayout.LayoutParams tapParams = (LinearLayout.LayoutParams) tapToReadText.getLayoutParams();
        tapParams.topMargin = 8;
        tapToReadText.setLayoutParams(tapParams);

        ImageView deleteButton = new ImageView(this);
        deleteButton.setLayoutParams(new LinearLayout.LayoutParams(48, 48));
        deleteButton.setImageResource(android.R.drawable.ic_menu_delete);
        deleteButton.setContentDescription("Supprimer cette archive");
        deleteButton.setBackgroundResource(android.R.drawable.btn_default);
        deleteButton.setPadding(8, 8, 8, 8);

        deleteButton.setOnClickListener(v -> {
            new AlertDialog.Builder(ArchiveActivity.this)
                    .setTitle("Supprimer l'histoire ?")
                    .setMessage("Voulez-vous vraiment supprimer cette histoire archivée ?")
                    .setPositiveButton("Oui", (dialog, which) -> {
                        deleteArchivedStory(position);
                        loadArchivedStories();
                        Toast.makeText(ArchiveActivity.this, "Histoire supprimée", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Non", null)
                    .show();
        });

        textContainer.addView(titleText);
        textContainer.addView(dateText);
        textContainer.addView(tapToReadText);

        contentLayout.addView(imageView);
        contentLayout.addView(textContainer);
        contentLayout.addView(deleteButton);

        cardView.addView(contentLayout);

        cardView.setOnClickListener(v -> {
            Intent intent = new Intent(ArchiveActivity.this, StoryActivity.class);
            intent.putExtra("STORY_TITLE", title);
            intent.putExtra("STORY_CONTENT", content);
            intent.putExtra("STORY_THEME", theme);
            intent.putExtra("STORY_CHARACTER", character);
            startActivity(intent);
        });

        archiveContainer.addView(cardView);
    }

    private void setThemeImage(ImageView imageView, String theme) {
        int colorRes;
        switch (theme.toLowerCase()) {
            case "aventure":
                colorRes = android.R.color.holo_blue_light;
                break;
            case "animaux":
                colorRes = android.R.color.holo_green_light;
                break;
            case "nature":
                colorRes = android.R.color.holo_green_dark;
                break;
            case "héros":
                colorRes = android.R.color.holo_red_light;
                break;
            default:
                colorRes = android.R.color.holo_orange_light;
                break;
        }
        imageView.setBackgroundColor(ContextCompat.getColor(this, colorRes));

        int iconRes;
        switch (theme.toLowerCase()) {
            case "aventure":
                iconRes = android.R.drawable.ic_menu_compass;
                break;
            case "animaux":
                iconRes = android.R.drawable.ic_menu_myplaces;
                break;
            case "nature":
                iconRes = android.R.drawable.ic_menu_gallery;
                break;
            case "héros":
                iconRes = android.R.drawable.ic_menu_send;
                break;
            default:
                iconRes = android.R.drawable.ic_menu_view;
                break;
        }

        imageView.setImageResource(iconRes);
        imageView.setScaleType(ImageView.ScaleType.CENTER);
        imageView.setColorFilter(ContextCompat.getColor(this, android.R.color.white));
    }

    private void deleteArchivedStory(int position) {
        SharedPreferences sharedPreferences = getSharedPreferences("archived_stories", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        int archivedCount = sharedPreferences.getInt("archived_count", 0);

        for (int i = position; i < archivedCount - 1; i++) {
            editor.putString("archived_title_" + i, sharedPreferences.getString("archived_title_" + (i + 1), ""));
            editor.putString("archived_content_" + i, sharedPreferences.getString("archived_content_" + (i + 1), ""));
            editor.putString("archived_theme_" + i, sharedPreferences.getString("archived_theme_" + (i + 1), ""));
            editor.putString("archived_character_" + i, sharedPreferences.getString("archived_character_" + (i + 1), ""));
            editor.putString("archived_date_" + i, sharedPreferences.getString("archived_date_" + (i + 1), ""));
        }

        // Supprimer la dernière entrée
        editor.remove("archived_title_" + (archivedCount - 1));
        editor.remove("archived_content_" + (archivedCount - 1));
        editor.remove("archived_theme_" + (archivedCount - 1));
        editor.remove("archived_character_" + (archivedCount - 1));
        editor.remove("archived_date_" + (archivedCount - 1));

        editor.putInt("archived_count", archivedCount - 1);
        editor.apply();
    }
}